# Reusable release-notes workflow — design

Date: 2026-07-21
Repository: `rahgozar94725/release-workflows` (public, MIT)

## Goal

Extract the git-cliff release-notes logic proven in MTProto-Checker into a
`workflow_call` workflow other repositories call. The build job stays
project-specific; only the release job becomes a call.

## Ground truth

Two sources, both authoritative, neither to be redesigned:

1. **MTProto-Checker commit `edb43e0`** — the release job, guard A, the
   `--current --use-branch-tags` invocation, the stable/pre-release branching.
   Ran in CI as run `29800347803` (tag `v0.0.1-test.1`), which logged
   `changelog OK (prerelease=true): 6 bullet(s), 6 commit link(s)`.
2. **The v2 text** — remote-derived `cliff.toml` URL, `--github-repo`/`--offline`,
   and guard B v2. Developed and verified outside any repository; **never
   committed anywhere and never run in CI.**

`edb43e0`'s `cliff.toml` hardcodes `https://github.com/rahgozar94725/MTProto-Checker`
in the template. The v2 form supersedes it. That commit is reference material,
not a thing to preserve as-is.

Because source 2 has never run in CI, criterion 1 is a genuine test of it, not a
regression check. If the byte-identical result does not hold, the v2 text is
what is wrong, not the runner.

### Verified behaviours preserved

- `--current`, not `--latest`. `--latest` resolves to the newest tag in the
  repository, not the tag being built, and fills an older release with a newer
  tag's commits.
- `--use-branch-tags`. Without it a repository's first tag fails with
  `ChangelogError("No suitable tags found")`. `--topo-order` does not fix it.
- `--github-repo "${GITHUB_REPOSITORY}" --offline`, both mandatory. On the
  detached HEAD `actions/checkout` produces, `remote.github.owner` and
  `remote.github.repo` render empty and every link becomes
  `https://github.com///commit/<sha>` — exit 0, notes published, guard B v1
  passing. Without `--offline`, `--github-repo` panics on an
  `api.github.com/repos/.../pulls` call.
- Stable tags get `--tag-pattern '^v[0-9]+\.[0-9]+\.[0-9]+$'`; pre-release tags
  get no pattern. Applying the pattern to an rc tag exits 1 with
  `No tag exists for the current commit` and writes no file. One regex drives
  both the tag-set filter and the `prerelease` flag, so they cannot drift.
- git-cliff pinned at 2.13.1, so rebuilding an old tag cannot pick up rendering
  from a newer 2.x.
- Derived-URL equivalence: on a detached checkout at `v2.0.0`, the derived form
  plus the two flags renders byte-identical to the literal form — 2147 bytes,
  md5 `06655476c601845e` for both.

## Architecture

One file does the work: `.github/workflows/release.yml`, `on: workflow_call`,
one job, five steps — checkout, generate changelog (guards A and B inline),
download artifacts, list artifacts, create release.

What stays with the caller: the build job, `cliff.toml`, the tag trigger, and
`permissions: contents: write`.

`cliff.toml` in this repository is a reference copy and **must not be consumed
at runtime**. That is not a policy choice, it is a mechanical fact: GitHub
fetches a called workflow as a single file and runs it against the caller's
checkout, so no sibling file in this repository exists on the runner.

### Interface

Two inputs: `artifact-glob` (required) and `config-path` (optional, default
`cliff.toml`). Everything else — git-cliff 2.13.1, the stable regex,
`ubuntu-latest`, `fetch-depth: 0`, `softprops/action-gh-release@v2` — is fixed
by the pinned SHA.

The rule, recorded verbatim:

> Every hardcoded value is one that was verified; every input is a knob a
> consumer can turn to an unverified value. Widening later is backward
> compatible, narrowing is not.

Consumers pin by SHA with the version in a trailing comment. A moving tag ref
defeats the purpose: it lets this repository repoint a consumer at code that
consumer never reviewed.

## Named decisions

### Absence of `set -euo pipefail`

The `Generate changelog` step deliberately runs under GitHub's default
`bash -e {0}` and **must not** gain `set -euo pipefail`. This is the decision
most likely to be undone by someone hardening the file, because an absent line
does not announce itself. A one-line comment at the top of the run block points
here.

Mechanism: guard B counts links with pipelines of the form

```sh
ALL_LINKS=$(grep -oE 'https://[^)]*/commit/[0-9a-f]{40}' RELEASE_NOTES.md | wc -l | tr -d ' ')
```

`grep` exits 1 when it matches nothing. Under plain `-e` the pipeline's status
is `tr`'s, so the zero-match case assigns `0` and the assertions run and report.
Under `pipefail` the step aborts at that line with no annotation. Verified: the
guard reaches `ALL_LINKS=0` and exits 0 without it; with `set -euo pipefail` it
exits 1 before the assertion ever runs.

Two of the seven fixtures — missing config (12 bullets, 0 links) and empty file
(0 bullets) — depend on this. Hardening the shell would silently delete the
guard's ability to say what went wrong.

### Guards stay inline

Guard B lives inline in the workflow YAML, byte-for-byte as verified. It is not
extracted to a script. See rejected alternatives.

### `ls -l ${GLOB}` fails on no match

The listing step expands the glob unquoted and does not suppress `ls`'s exit
status. Unmatched glob exits 2, matched exits 0 — verified. A release published
with zero assets is a failure worth stopping on, and stopping here is louder
than letting `softprops/action-gh-release` attach nothing. The positive path is
proven by criterion 1; the negative path is not.

## Departures from ground truth

Five, all deliberate, all reviewed:

1. `echo "prerelease=${PRERELEASE}" >> "$GITHUB_OUTPUT"` re-inserted. It sat
   inside the block guard B v2 replaced and is absent from the v2 text. Without
   it the release action receives `prerelease: ""`.
2. `-c "${CONFIG}"` added to the invocation, forced by the `config-path` input.
   The default value equals git-cliff's implicit default, so criterion 1
   exercises the exact string; a non-default value ships unproven.
3. Guard A's message interpolates `${CONFIG}` instead of the literal
   `cliff.toml`.
4. `find . -name 'mtproto-checker-*' -type f` replaced by `ls -l ${GLOB}` — the
   original was project-specific and could not survive.
5. `set -euo pipefail` deliberately absent, as above.

## Rejected alternatives

### Extracting the guard to a script in this repository

Rejected. A reusable workflow runs in the caller's context; GitHub makes only
the workflow file available. Reaching `scripts/check-release-notes.sh` requires
a second `actions/checkout` with `repository:`, `ref:` and `path:` — the same
machinery already rejected when shape B was ruled out.

**The ref derivation is worse than untested, it may be wrong.**
`github.job_workflow_sha` is documented as the commit SHA for the reusable
workflow file, but is reported to return the workflow repository's *latest*
commit instead, changing whenever any unrelated file such as `README.md` is
pushed ([community discussion #146280](https://github.com/orgs/community/discussions/146280)).
Anyone revisiting this will reach for that context variable first. It is not a
reliable pin.

### A composite action instead of a script

**Mechanism works, not built.** `uses: owner/repo/path@ref` makes the whole
action repository available at runtime, and `$GITHUB_ACTION_PATH` locates files
shipped beside `action.yml`; GitHub's own tutorial runs a `goodbye.sh` that way.
No manual checkout needed.

Its cost is larger than a self-referential pin alone. Inside a reusable workflow
you cannot write `uses: ./actions/<name>` — relative action refs resolve against
the *caller's* workspace
([#107558](https://github.com/orgs/community/discussions/107558),
[#167025](https://github.com/orgs/community/discussions/167025)). So this
workflow would have to carry the full
`rahgozar94725/release-workflows/actions/<name>@<sha>`, bumped on every guard
edit and unresolvable until after the commit exists. The testability win lands
only in this repository's own CI, which is an ordinary workflow and *can* use
`./actions/<name>`.

Recorded so it is not rediscovered. Revisit only once the guard stops changing.

### A fixture suite running in CI

Deferred. The seven fixtures are recorded evidence, hand-verified outside CI,
explicitly **not a running regression net**. Revisit together with the composite
action, once the guard stops changing.

### Fully parameterized inputs

Rejected. `git-cliff-version` as an input defeats the pin — a consumer could set
2.14 and get different rendering from a workflow whose SHA claims it was proven.
`stable-tag-pattern` breaks the one-regex-two-uses invariant unless it also
drives the `prerelease` flag.

### Optional `artifact-glob`

Deferred, and this is a **known future input, not a hypothetical.**
`rahgozar94725/CDN-Config-Generator` is a static site deployed to Pages and
almost certainly produces no binaries, so a notes-only path will be needed. Not
added now because criterion 1 does not exercise the empty-glob path, and it
would ship unproven. Add and prove it when that repository is actually
converted, not before.

## Guards

**A — missing config.** git-cliff does not fail when its config is absent: one
WARN, exit 0, rendered with its built-in default (no commit links, different
group names). An explicit `-c` does not change that. The step refuses to run
when `config-path` is not present at the tag being built.

Consequence, deliberate: tags predating the config cannot be rebuilt until they
carry it. Failing beats publishing notes in an unreviewed format.

**B — wrong artifact.** Asserts the output, not the input:

- at least one bullet rendered;
- `ALL_LINKS == BULLETS`, one commit link per bullet;
- `OUR_LINKS == BULLETS`, every link under `https://github.com/$GITHUB_REPOSITORY`;
- `CMP_ALL == CMP_OURS`, the compare link points there too — zero tolerated,
  wrong rejected, which is what lets a first release pass.

Design points preserved verbatim: `ALL_LINKS` and `OUR_LINKS` stay separate
because they diagnose different failures; `-F` throughout, so a repository name
containing `.` or `+` cannot be read as a regex; and the empty
`GITHUB_REPOSITORY` check is load-bearing, because an empty value collapses the
expected prefix to `https://github.com/` and would match the very malformed URLs
the guard exists to catch.

### Fixture evidence

Seven fixtures, six distinct behaviours, run by hand against real generated
files. Hand-verified outside CI; nothing re-runs them.

| Fixture | Result | Detail |
| --- | --- | --- |
| `v2.0.0`, normal release | PASS | 12 bullets, 12 ours, 1 compare |
| `v1.0.0`, first release | PASS | 11 bullets, 11 ours, 0 compare |
| unset owner/repo | FAIL | `0/12 commit link(s) point at …` |
| config copied, wrong repo | FAIL | same message |
| missing config, default fallback | FAIL | `12 bullet(s) but 0 commit link(s)` |
| empty file | FAIL | `no bullets rendered` |
| `GITHUB_REPOSITORY` unset | FAIL | `cannot verify link ownership` |

## Open question

`permissions: contents: write` is declared at workflow level in the called
workflow. How that interacts with the caller's own `permissions` block and the
caller's default token scope is **not assumed**. Criterion 1 exercises it for
real; the observed result is the answer and gets written down, including whether
the caller needs its own block. A failure there is a finding, not a bug to paper
over.

## Test plan

### Resolving the pin/tag circularity

You cannot pin to a SHA before one exists, and no tag should exist before the
workflow is proven. Resolution: **pin the test caller to the commit SHA
directly, not to a branch and not to a tag.**

`uses: …/release.yml@<sha>` accepts any full commit SHA on any branch; the
commit need not be tagged. So the order is: commit here → the SHA exists
immediately → the test caller pins that exact SHA → run → tag `v1.0.0` on the
same commit once criteria 1–3 pass. **No repin is needed**, because tagging does
not change the SHA; the trailing `# v1.0.0` comment simply becomes true. If the
guard needs a fix, the new commit gets a new SHA and a new test tag, which is
the same cost branch-pinning would have had.

This repository's `README.md` still shows `@<sha>` as a placeholder, because a
README cannot contain the SHA of the commit that contains it.

**Untested and load-bearing.** That a reusable workflow can be referenced by a
SHA which is neither on the default branch nor carries a tag has not been
confirmed on a runner; it is not to be mistaken for something verified. It is
self-testing: if it is false, criterion 1 fails immediately and cheaply, before
anything is published.

### Criteria

1. A test call from a throwaway branch of MTProto-Checker, pinned to this
   repository's commit SHA, tagged `v0.0.1-test.2`, produces output
   byte-identical to run `29800347803`: 6 bullets, 6 links, `prerelease=true`,
   compare against `v2.0.1`.
2. Six distinct behaviours across the seven guard-B fixtures. (The original
   wording said six fixtures; `unset owner/repo` and `config copied, wrong repo`
   emit the identical message and collapse to one distinct behaviour.)
3. Emoji survive to the rendered GitHub release page.
4. README carries an adoption checklist including the Conventional Commits and
   tag-pattern preconditions.
5. Tag `v1.0.0` only after 1–3 pass.

### Constraint on MTProto-Checker

Nothing lands on MTProto-Checker's `main`, and no permanent artifact survives on
that repository. The throwaway branch carries the remote-based `cliff.toml` and
a caller `release.yml`; the tag triggers the run; branch, tag and release are
all deleted afterwards. Run logs remain, as `v0.0.1-test.1`'s did.

**Teardown is gated.** Push branch, push tag, report the run with the release
URL, then stop. Teardown happens only after explicit confirmation that the
rendered page was inspected. This is the order that worked on 2026-07-21 and
left nothing behind.

## Out of scope

Bootstrap or preflight scripts; a Claude Code skill; converting other projects;
MTProto-Checker's own final conversion.
